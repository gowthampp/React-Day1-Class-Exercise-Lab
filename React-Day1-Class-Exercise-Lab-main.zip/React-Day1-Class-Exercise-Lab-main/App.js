
import './App.css';
import World from './Component/World';


function App() {
  return (
    <div className="App">
      This Our Project
<World/>
    </div>
  );
}

export default App;
