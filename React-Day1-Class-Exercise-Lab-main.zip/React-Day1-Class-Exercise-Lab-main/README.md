# React-Day2-React_Component
class
